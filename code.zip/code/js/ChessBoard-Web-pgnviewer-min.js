class ChessViewer{constructor(e){this.containerId=e.containerId,this.pgn=e.pgn||"",this.boardWidth=e.boardWidth||400,this.annotations=e.annotations||{},this.nagSymbolMap={1:"!",2:"?",3:"!!",4:"??",5:"!?",6:"?!",7:"□",10:"=",13:"∞",14:"⩲",15:"⩱",16:"\xb1",17:"∓",18:"+-",19:"-+"},this.nagColorMap={"!":"#06adae","!!":"#06adae","?":"#e69a29","??":"#e74c3c","!?":"#9b59b6","?!":"#f7be42","□":"#0b0b0b"},this.boardConfig=Object.assign({position:"start",draggable:!1,showNotation:!0,pieceTheme:"img/chesspieces/wikipedia/{piece}.png"},e.boardConfig||{}),this.parsedTree=[],this.nodeMap={},this.currentNodeId=null,this.board=null,this._injectStyles(),this._buildUI(),this._initChess(),this._bindEvents()}_injectStyles(){if(document.getElementById("chess-viewer-styles"))return;let e=document.createElement("style");e.id="chess-viewer-styles",e.innerHTML=`
      /* total container */
      .cv-container {
        display: inline-flex;
        align-items: flex-start;
        gap: 20px;
        background: #1e1e1e;
        padding: 24px;
        border-radius: 12px;
        box-shadow: 0 12px 32px rgba(0, 0, 0, 0.45);
        color: #bababa;
        font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, "Helvetica Neue", Arial, sans-serif;
        box-sizing: border-box;
      }

      /* chess board section */
      .cv-board-section {
        display: flex;
        flex-direction: column;
        gap: 16px;
        flex-shrink: 0;
        /* fixing CSS line height  */
        line-height: normal; 
      }

      /* control button styles */
      .cv-controls {
        display: flex;
        gap: 8px;
        background-color: #262522;
        padding: 6px;
        border-radius: 8px;
        box-sizing: border-box;
      }

      .cv-btn {
        flex: 1;
        height: 38px;
        display: flex;
        align-items: center;
        justify-content: center;
        background-color: transparent;
        color: #989795;
        border: none;
        border-radius: 6px;
        cursor: pointer;
        transition: all 0.2s ease;
      }
      .cv-btn:hover { background-color: #363431; color: #ffffff; }
      .cv-btn:active { transform: scale(0.96); }
      .cv-btn svg { width: 18px; height: 18px; fill: currentColor; }

      /* notation(a1~h8) fixes */
      .notation-322f9 {
        font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", sans-serif !important;
        font-weight: 600 !important;
        font-size: 11px !important;
        cursor: default;
      }

      /* sidebar styles */
      .cv-sidebar {
        width: 320px;
        display: flex;
        flex-direction: column;
        background-color: #262522;
        border-radius: 8px;
        overflow: hidden;
        border: 1px solid rgba(255, 255, 255, 0.05);
        box-sizing: border-box;
      }

      .cv-header {
        padding: 12px 16px;
        background-color: #21201d;
        font-size: 12px;
        font-weight: 700;
        color: #8b8987;
        letter-spacing: 0.8px;
        border-bottom: 1px solid rgba(255, 255, 255, 0.05);
        text-transform: uppercase;
        flex-shrink: 0;
      }

      .cv-moves-list {
        flex: 1;
        overflow-y: auto;
        overflow-x: hidden;
        display: flex;
        flex-direction: column;
      }

      /* scroll bar styles */
      .cv-moves-list::-webkit-scrollbar { width: 6px; }
      .cv-moves-list::-webkit-scrollbar-track { background: #262522; }
      .cv-moves-list::-webkit-scrollbar-thumb { background: #3d3b38; border-radius: 3px; }
      .cv-moves-list::-webkit-scrollbar-thumb:hover { background: #524f4b; }

      /* move list styles */
      .cv-move-row { display: flex; font-size: 14px; line-height: 34px; flex-shrink: 0; }
      .cv-move-row.even, .cv-move-row:nth-child(even) { background-color: rgba(0, 0, 0, 0.15); }

      .cv-move-num {
        width: 44px; text-align: center; color: #666564;
        background-color: rgba(0, 0, 0, 0.25); font-size: 12px;
        font-weight: 600; user-select: none; flex-shrink: 0;
      }

      .cv-move-cell {
        flex: 1; padding: 0 12px; cursor: pointer; color: #c3c2c0;
        border-radius: 4px; margin: 2px;
        transition: background-color 0.15s ease, color 0.15s ease;
        white-space: nowrap; overflow: hidden; text-overflow: ellipsis;
      }
      .cv-move-cell.empty { cursor: default; }
      .cv-move-cell:not(.empty):hover { background-color: #363431; color: #ffffff; }

      .cv-move-cell.active, .cv-move-item.active {
        background-color: #3692e7 !important;
        color: #ffffff !important;
        font-weight: 600;
        box-shadow: 0 2px 6px rgba(54, 146, 231, 0.3);
      }

      .cv-nag { font-weight: bold; margin-left: 3px; }

      /* comment and variation styles */
      .cv-comment {
        background: #1a1917; border-left: 3px solid #f39c12;
        padding: 8px 12px; font-size: 13px; color: #d1d0ce;
        line-height: 1.5; box-sizing: border-box;
        word-break: break-word; white-space: pre-wrap;
      }

      .cv-inline-comment {
        display: inline-block; color: #999; font-style: italic;
        margin: 0 4px; word-break: break-word;
      }

      .cv-variation-block {
        padding: 8px 12px; background: rgba(0, 0, 0, 0.35);
        border-left: 2px solid #524f4b; box-sizing: border-box;
      }
      .cv-move-inline-wrap {
        display: inline-flex; flex-wrap: wrap; align-items: center;
        gap: 4px; font-size: 13px;
      }
      .cv-move-item {
        display: inline-flex; align-items: center; padding: 2px 6px;
        border-radius: 4px; cursor: pointer; color: #b0b0b0;
        background-color: rgba(255, 255, 255, 0.04); transition: all 0.15s;
      }
      .cv-move-item:hover { background-color: #363431; color: #fff; }
      .cv-move-number { color: #777; margin-right: 4px; font-weight: bold; }
      .cv-paren { color: #666; font-weight: bold; }
    `,document.head.appendChild(e)}_buildUI(){let e=$(`#${this.containerId}`);e.empty();let o=`${this.containerId}-board`,t=`${this.containerId}-moves`,i=this.boardWidth+50;e.html(`
      <div class="cv-container">
        <div class="cv-board-section" style="width: ${this.boardWidth}px;">
          <!-- setting height and width of chessboard wrapper inline -->
          <div id="${o}" style="width: ${this.boardWidth}px; height: ${this.boardWidth}px;"></div>
          
          <div class="cv-controls">
            <button class="cv-btn btn-start" title="First Move">
              <svg viewBox="0 0 24 24"><path d="M18.4 16.6L12.8 12l5.6-4.6L17 6l-7 6 7 6zM6 6h2v12H6z"/></svg>
            </button>
            <button class="cv-btn btn-prev" title="Previous Move">
              <svg viewBox="0 0 24 24"><path d="M15.41 7.41L14 6l-6 6 6 6 1.41-1.41L10.83 12z"/></svg>
            </button>
            <button class="cv-btn btn-next" title="Next Move">
              <svg viewBox="0 0 24 24"><path d="M10 6L8.59 7.41 13.17 12l-4.58 4.59L10 18l6-6z"/></svg>
            </button>
            <button class="cv-btn btn-end" title="Last Move">
              <svg viewBox="0 0 24 24"><path d="M5.6 7.4L11.2 12 5.6 16.6 7 18l7-6-7-6zM16 6h2v12h-2z"/></svg>
            </button>
          </div>
        </div>
        
        <div class="cv-sidebar" style="height: ${i}px;">
          <div class="cv-header">Moves & Variations</div>
          <div class="cv-moves-list" id="${t}"></div>
        </div>
      </div>
    `),this.$boardEl=$(`#${o}`),this.$movesEl=$(`#${t}`),this.$container=e.find(".cv-container")}_initChess(){this.board=Chessboard(this.$boardEl.attr("id"),this.boardConfig),this._parsePgnWithVariations(this.pgn),this._renderTreeUI(),this.goToNode("root"),setTimeout(()=>{this.board&&"function"==typeof this.board.resize&&this.board.resize()},50)}_parsePgnWithVariations(e){let o=e.replace(/\[\s*[\w\d]+\s+"[^"]*"\s*\]/g,"").trim(),t=[],i=0;for(;i<o.length;){let n=o[i];if("{"===n){let s=o.indexOf("}",i);-1===s&&(s=o.length),t.push({type:"comment",value:o.substring(i+1,s).trim()}),i=s+1}else if("("===n||")"===n)t.push({type:"paren",value:n}),i++;else if(/\s/.test(n))i++;else{let r=i;for(;i<o.length&&!/[\s{}()]/.test(o[i]);)i++;t.push({type:"token",value:o.substring(r,i)})}}let l={id:"root",fen:"rnbqkbnr/pppppppp/8/8/8/8/PPPPPPPP/RNBQKBNR w KQkq - 0 1",children:[],parent:null};this.nodeMap={root:l};let a=l,c=[],d=1;for(let p=0;p<t.length;p++){let h=t[p];if("comment"===h.type){let v=h.value.replace(/\[%c[as]l\s+[^\]]+\]/gi,"").trim();v&&(a.comment=(a.comment?a.comment+" ":"")+v)}else if("paren"===h.type)"("===h.value?(c.push(a),a.parent&&(a=a.parent)):")"===h.value&&c.length>0&&(a=c.pop());else if("token"===h.type){let f=h.value;if(f.match(/^\d+\./)||["1-0","0-1","1/2-1/2","*"].includes(f))continue;let b=f,m="",g=f.match(/\$(\d+)/);g&&(m=this.nagSymbolMap[parseInt(g[1],10)]||`$${g[1]}`,b=f.replace(/\$\d+/,""));let u=b.match(/(!{1,2}|\?{1,2}|!\?|\?!|⩲|⩱|±|∓|\+-|-\+|=)/);if(u&&(m=u[0],b=b.replace(u[0],"")),!b)continue;let x=new Chess(a.fen),_=x.move(b,{sloppy:!0});if(_){let y=`node_${d++}`,w=parseInt(a.fen.split(" ")[5],10),k={id:y,san:_.san,color:_.color,moveNum:w,nag:m,fen:x.fen(),children:[],parent:a,moveIndex:d-1};a.children.push(k),this.nodeMap[y]=k,a=k}}}this.parsedTree=l.children}_getFormat(e){let o=this.annotations[e.moveIndex],t=this.nagColorMap[e.nag]||"",i="",n=t,s="",r="";return t&&(i=t),o&&"object"==typeof o&&(o.textColor&&(i=o.textColor),o.nagColor&&(n=o.nagColor),o.suffix&&(s=o.suffix),o.suffixColor&&(r=o.suffixColor)),{color:i,nagColor:n,suffix:s,suffixColor:r}}_renderTreeUI(){if(this.$movesEl.empty(),!this.parsedTree.length)return;let e=this.parsedTree[0],o=null,t=0,i=(e,o=!1)=>{t++;let i=t%2==0?"even":"odd",n=$(`<div class="cv-move-row ${i}"></div>`);return n.append(`<div class="cv-move-num">${o?e+"...":e}</div>`),n},n=e=>{let o=this._getFormat(e),t=o.color?`color: ${o.color};`:"",i=o.nagColor?`color: ${o.nagColor};`:"",n=o.suffix?`<span style="margin-left:4px; font-weight:normal; color:${o.suffixColor||o.color||"#999"}">${o.suffix}</span>`:"";return`<span style="${t}">${e.san}</span>${e.nag?`<span class="cv-nag" style="${i}">${e.nag}</span>`:""}${n}`};for(;e;){if("w"===e.color){(o=i(e.moveNum)).append(`<div class="cv-move-cell" data-node-id="${e.id}">${n(e)}</div>`);let s=!!e.comment,r=e.parent&&e.parent.children.length>1&&e===e.parent.children[0];(s||r)&&(o.append('<div class="cv-move-cell empty"></div>'),this.$movesEl.append(o),o=null,s&&this.$movesEl.append(`<div class="cv-comment">${e.comment}</div>`),r&&this._renderSublinesBlock(e.parent,this.$movesEl))}else{o||(o=i(e.moveNum,!0)).append('<div class="cv-move-cell empty"></div>'),o.append(`<div class="cv-move-cell" data-node-id="${e.id}">${n(e)}</div>`),this.$movesEl.append(o),o=null;let l=!!e.comment,a=e.parent&&e.parent.children.length>1&&e===e.parent.children[0];l&&this.$movesEl.append(`<div class="cv-comment">${e.comment}</div>`),a&&this._renderSublinesBlock(e.parent,this.$movesEl)}e=e.children[0]}o&&(o.append('<div class="cv-move-cell empty"></div>'),this.$movesEl.append(o))}_renderSublinesBlock(e,o){for(let t=1;t<e.children.length;t++){let i=$('<div class="cv-variation-block"></div>'),n=$('<div class="cv-move-inline-wrap"></div>');this._renderInlineSubTree(e.children[t],n),i.append(n),o.append(i)}}_renderInlineSubTree(e,o){let t=e,i=!0;for(;t;){let n="w"===t.color||i,s="w"===t.color?`${t.moveNum}.`:`${t.moveNum}...`,r=this._getFormat(t),l=r.color?`style="color: ${r.color};"`:"",a=r.nagColor?`style="color: ${r.nagColor};"`:"",c=r.suffix?`<span style="margin-left:4px; font-weight:normal; color:${r.suffixColor||r.color||"#999"}">${r.suffix}</span>`:"",d=$(`
        <div class="cv-move-item" data-node-id="${t.id}">
          ${n?`<span class="cv-move-number">${s}</span>`:""}
          <span ${l}>${t.san}</span>
          ${t.nag?`<span class="cv-nag" ${a}>${t.nag}</span>`:""}
          ${c}
        </div>
      `);if(o.append(d),i=!1,t.comment&&(o.append(`<div class="cv-inline-comment">${t.comment}</div>`),i=!0),t.children.length>1){for(let p=1;p<t.children.length;p++)o.append('<span class="cv-paren">(</span>'),this._renderInlineSubTree(t.children[p],o),o.append('<span class="cv-paren">)</span>');i=!0}t=t.children[0]}}_bindEvents(){let e=this;this.$container.find(".btn-start").on("click",()=>this.goToNode("root")),this.$container.find(".btn-prev").on("click",()=>{this.currentNodeId&&this.nodeMap[this.currentNodeId]?.parent&&this.goToNode(this.nodeMap[this.currentNodeId].parent.id)}),this.$container.find(".btn-next").on("click",()=>{let e=this.nodeMap[this.currentNodeId];e&&e.children.length>0&&this.goToNode(e.children[0].id)}),this.$container.find(".btn-end").on("click",()=>{let e=this.nodeMap[this.currentNodeId]||this.nodeMap.root;for(;e&&e.children.length>0;)e=e.children[0];e&&this.goToNode(e.id)}),this.$movesEl.on("click",".cv-move-cell, .cv-move-item",function(){if($(this).hasClass("empty"))return;let o=$(this).data("node-id");o&&e.goToNode(o)})}goToNode(e){let o=this.nodeMap[e];if(o){if(this.currentNodeId=e,this.board.position(o.fen,!0),this.$movesEl.find(".cv-move-cell, .cv-move-item").removeClass("active"),"root"!==e){let t=this.$movesEl.find(`[data-node-id="${e}"]`);if(t.addClass("active"),t.length){let i=t.offset().top-this.$movesEl.offset().top+this.$movesEl.scrollTop(),n=this.$movesEl.height();(i<this.$movesEl.scrollTop()||i>this.$movesEl.scrollTop()+n-40)&&this.$movesEl.scrollTop(i-n/3)}}this._applyAnnotations(o)}}_applyAnnotations(e){if("function"==typeof this.board.clearHighlights&&this.board.clearHighlights(),"function"==typeof this.board.clearShapes&&this.board.clearShapes(),"function"==typeof this.board.clearNagBadges&&this.board.clearNagBadges(),e.moveIndex){let o=this.annotations[e.moveIndex];"function"==typeof o?o(this.board,e):"object"==typeof o&&"function"==typeof o.fn&&o.fn(this.board,e)}}}